<?php
// Heading
$_['heading_title'] = 'Total Orders';

// Text
$_['text_view']     = 'View more...';