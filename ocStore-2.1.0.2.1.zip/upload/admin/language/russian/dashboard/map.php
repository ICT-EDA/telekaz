<?php
// Heading
$_['heading_title'] = 'Продажи по странам';

$_['text_order']    = 'Заказы';
$_['text_sale']     = 'Продажи';