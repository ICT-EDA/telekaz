<?php
// Heading
$_['heading_title'] = 'Покупатели онлайн';

// Text
$_['text_view']     = 'Подробнее...';