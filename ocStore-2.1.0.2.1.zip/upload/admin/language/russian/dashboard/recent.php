<?php
// Heading
$_['heading_title']     	 = 'Последние заказы';

// Column
$_['column_order_id']        = 'Заказ №';
$_['column_customer']        = 'Покупатель';
$_['column_status']          = 'Статус';
$_['column_total']           = 'На сумму';
$_['column_date_added']      = 'Дата заказа';
$_['column_action']          = 'Действие';
