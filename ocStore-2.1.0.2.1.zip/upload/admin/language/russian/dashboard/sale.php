<?php
// Heading
$_['heading_title'] = 'Всего продаж';

// Text
$_['text_view']     = 'Подробнее...';