<?php
// Heading
$_['heading_title']    = 'Captcha';

// Text
$_['text_success']     = 'Настройки службы успешно обновлены';
$_['text_list']        = 'Список доступных CAPTCHA';

// Column
$_['column_name']      = 'Название службы';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'У Вас нет прав для управления этим модулем!';
